#include "ESPRobotV2.h"


${EXTINC}


${VARIABLE}

${FUNCTION}

void setup()
{
	
	ESPRobotV2();
    /* setup code */
${SETUP_CODE}
    /* block setup */
${BLOCKSETUP}
}

void loop()
{
  ${LOOP_CODE}
  ${LOOP_EXT_CODE}
}
